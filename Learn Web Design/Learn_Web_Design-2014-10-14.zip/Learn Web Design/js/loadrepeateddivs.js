function loadRepeatedDivs(){

    $("#navigation-bar").load("https://4598ceb4dd3fa10814247ba1accd1c31c1c9f9dd.googledrive.com/host/0B5kZdBK1QTn1amM4clB3Vng0SlU/loadnavigationbar.html");

    $("#contact-pop-up").load("https://4598ceb4dd3fa10814247ba1accd1c31c1c9f9dd.googledrive.com/host/0B5kZdBK1QTn1amM4clB3Vng0SlU/loadcontactpopup.html");
    
    $("#google-drive-sidebar").load("#");
    
    $("#footnote").load("#");

}

jQuery(document).ready(function() { loadRepeatedDivs(); });